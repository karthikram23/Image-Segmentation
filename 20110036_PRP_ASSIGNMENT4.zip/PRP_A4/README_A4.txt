       Assignment 4 : Image Segmentation using Randowm walker   

                                                                      Name: Balu Kathik Ram
                                                                      Roll No: 20110036

 
1.  In sequentially, run all the cells.

 2. To give seeds to the image, from the second cell it causes the image's popup window to open, 
     where you may use your cursor to add seeds.

 3. For changing the labels you can press the numbers from 0-9 .
     the number depends on the number of classifications that you are going to do.

 4. Ater giving seeds, press "esc" button to close the popup window.

 5. Run all the functions to segment the image.

 6. The segmented and the original image should be displayed side by side, after pocessing.
